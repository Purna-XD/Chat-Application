How to run the project:

Extract and copy into your machine.
Contains 2 folders and a readme.txt
open both folders and just type make to run.
It will create server and client executables.
Just type ./server and ./client to run them.
To change ip or port number change in configuration_file in both folders(server and client).
All usernames are stored in the user.txt file.
main menu functions are login [username] and exit.
after login type any message to chat with other clients.
Pthreads is majorly implemented in the code.
All messages are routed to server before sending them to client.
Just type logout to logout the user.
