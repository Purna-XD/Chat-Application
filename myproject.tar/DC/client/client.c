#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <pthread.h>
#include <semaphore.h>
 
#define BUF_SIZE 100
#define NAME_SIZE 20
 
void * send_msg(void *arg);
void * recv_msg(void *arg);
void error_handling(char *message);
 
   char name[NAME_SIZE]="[DEFAULT]";
   char msg[BUF_SIZE];

 
   int main(int argc, char *argv[])
   {
   int sock;
   struct sockaddr_in serv_addr;
 
   pthread_t snd_thread, rcv_thread;
   void * thread_return;

   char n1,n2,n3,n4,n5,n6,d1,d2,d3;
   int num1,num2,num3,num4,num5;
   char str1[100],str2[100],str3[100],str4[100],str5[100],str6[100],str7[100];
   FILE *fptr;

   if ((fptr = fopen("configuration_file.txt","r")) == NULL){
       printf("Error! opening configuration_file");
       exit(1);
   }

   fscanf(fptr,"%c", &n1);
   fscanf(fptr,"%c", &n2);
   fscanf(fptr,"%c", &n3);
   fscanf(fptr,"%c", &n4);
   fscanf(fptr,"%c", &n5);
   fscanf(fptr,"%c", &n6);
   fscanf(fptr,"%c", &n1);
   fscanf(fptr,"%c", &n2);
   fscanf(fptr,"%c", &n1);
   fscanf(fptr,"%c", &n2);

   fscanf(fptr,"%d", &num1);
   fscanf(fptr,"%c", &d1);
   fscanf(fptr,"%d", &num2);
   fscanf(fptr,"%c", &d2);
   fscanf(fptr,"%d", &num3);
   fscanf(fptr,"%c", &d3);
   fscanf(fptr,"%d", &num4);

   fscanf(fptr,"%c", &n1);
   fscanf(fptr,"%c", &n2);
   fscanf(fptr,"%c", &n3);
   fscanf(fptr,"%c", &n4);
   fscanf(fptr,"%c", &n5);
   fscanf(fptr,"%c", &n6);
   fscanf(fptr,"%c", &n1);
   fscanf(fptr,"%c", &n2);
   fscanf(fptr,"%c", &n1);
   fscanf(fptr,"%c", &n2);
   fscanf(fptr,"%d", &num5);

   printf("Value of ip=%d%c%d%c%d%c%d\n", num1,d1,num2,d2,num3,d3,num4);
   if(num5==0)
   {
    num5=25700;
   }
   printf("Value of port=%d\n", num5);
   fclose(fptr);

   sprintf(str1,"%d",num1);
   sprintf(str2, "%c", d1);
   sprintf(str3, "%d", num2);
   sprintf(str4, "%c", d2);
   sprintf(str5, "%d", num3);
   sprintf(str6, "%c", d3);
   sprintf(str7, "%d", num4);

   strcat(str1, str2);
   strcat(str1, str3);
   strcat(str1, str4);
   strcat(str1, str5);
   strcat(str1, str6);
   strcat(str1, str7);

   if(argc!=1)
   {
     exit(1);
   }

   char input_value[100];
   char newString[10][10];
   int i,j,ctr;
   printf("Please login using login [your_name] to start chatting or type exit to close connection\n");
   fgets(input_value, sizeof input_value, stdin);   

    if(!strcmp(input_value,"exit\n") || !strcmp(input_value,"EXIT\n"))
      {
          close(sock);
          exit(0);
      }
    else
    {
    j=0; ctr=0;
    for(i=0;i<=(strlen(input_value));i++)
    {
        if(input_value[i]==' '||input_value[i]=='\0')
        {
            newString[ctr][j]='\0';
            ctr++;
            j=0;
        }
        else
        {
            newString[ctr][j]=input_value[i];
            j++;
        }
   }
   }
   if(strcmp(newString[0],"login")==0);
   {
    sprintf(name, "%s", newString[1]);
    FILE *fPtw;
    fPtw = fopen("user.txt", "a");
    if (fPtw == NULL)
    {
        printf("Please check whether file exists and you have write privilege.\n");
        exit(EXIT_FAILURE);
    }
    fputs(name, fPtw);
    fclose(fPtw);
   }
  //TCP socket
  sock=socket(PF_INET, SOCK_STREAM, 0);
  if(sock == -1)
    error_handling("socket error!");
  memset(&serv_addr, 0, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_addr.s_addr = inet_addr(str1);
  serv_addr.sin_port = htons(num5);
 
  if(connect(sock, (struct sockaddr*) &serv_addr, sizeof(serv_addr)) == -1)
    error_handling("connect error");
  
     //Create transceiver thread
  pthread_create(&snd_thread, NULL, send_msg, (void*)&sock);
  pthread_create(&rcv_thread, NULL, recv_msg, (void*)&sock);
     //The current process is blocked waiting for the thread to terminate recycling resources
  pthread_join(snd_thread, &thread_return);
  pthread_join(rcv_thread, &thread_return);
  
  close(sock);
  return 0;
}

void* send_msg(void* arg)
{
  int sock=*((int*)arg);
  char name_msg[NAME_SIZE+BUF_SIZE];
  while(1)
  {
    fgets(msg, BUF_SIZE, stdin);
    if(!strcmp(msg, "logout\n") || !strcmp(msg, "LOGOUT\n"))
    {
      close(sock);
      exit(0); 
      //need to have a goto function to login menu
    }
    sprintf(name_msg, ">>%s %s", name, msg);
    write(sock, name_msg, strlen(name_msg));
  }
  return NULL;
}
 
void* recv_msg(void* arg)
{
  int sock=*((int*)arg);
  char name_msg[NAME_SIZE+BUF_SIZE];
  int str_len;
  while(1)
  {
    str_len=read(sock, name_msg, NAME_SIZE+BUF_SIZE+1);
    if(str_len==-1)
      return (void*)-1;
    name_msg[str_len]=0;
    fputs(name_msg, stdout);
  }
  return NULL;
}

void error_handling(char *message)
{
  fputs(message, stderr);
  fputc('\n', stderr);
  exit(1);
}
